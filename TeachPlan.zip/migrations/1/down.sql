
DROP INDEX idx_modules_order;
DROP INDEX idx_modules_course_id;
DROP TABLE modules;
DROP TABLE courses;

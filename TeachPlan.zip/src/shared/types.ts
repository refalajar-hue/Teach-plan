import z from "zod";

export const CourseSchema = z.object({
  id: z.number(),
  title: z.string(),
  description: z.string(),
  target_audience: z.string(),
  duration: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const ModuleSchema = z.object({
  id: z.number(),
  course_id: z.number(),
  title: z.string(),
  learning_objectives: z.string(),
  quiz_question: z.string(),
  quiz_answer_a: z.string(),
  quiz_answer_b: z.string(),
  quiz_answer_c: z.string(),
  quiz_answer_d: z.string(),
  correct_answer: z.string(),
  module_order: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CourseWithModulesSchema = CourseSchema.extend({
  modules: z.array(ModuleSchema),
});

export type Course = z.infer<typeof CourseSchema>;
export type Module = z.infer<typeof ModuleSchema>;
export type CourseWithModules = z.infer<typeof CourseWithModulesSchema>;

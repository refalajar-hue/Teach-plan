import OpenAI from "openai";

export async function generateMultipleCourses(topics: string[], apiKey: string, language: string = 'en') {
  const client = new OpenAI({
    apiKey: apiKey,
  });

  const isArabic = language === 'ar';
  
  const prompt = isArabic ? 
    `أنشئ 5 مخططات دورات تدريبية تعليمية شاملة لهذه المواضيع: ${topics.join(', ')}

لكل دورة، يرجى تقديم:
1. عنوان الدورة (مهني وجذاب)
2. وصف الدورة (2-3 جمل)
3. الجمهور المستهدف (مجموعة محددة من المعلمين أو المهنيين)
4. المدة الزمنية (إطار زمني واقعي مثل "3 ساعات"، "يومان"، إلخ)
5. بالضبط 5 وحدات، كل منها تحتوي على:
   - عنوان الوحدة
   - أهداف التعلم (3-4 أهداف مفصولة بفاصلة منقوطة)
   - سؤال اختيار من متعدد واحد مع 4 خيارات (أ، ب، ج، د) والإجابة الصحيحة

قم بتنسيق الاستجابة كعنصر JSON بهذا الهيكل بالضبط:
{
  "courses": [
    {
      "title": "عنوان الدورة",
      "description": "وصف الدورة",
      "target_audience": "الجمهور المستهدف",
      "duration": "المدة",
      "modules": [
        {
          "title": "عنوان الوحدة الأولى",
          "learning_objectives": "الهدف الأول؛ الهدف الثاني؛ الهدف الثالث",
          "quiz_question": "ما هو المفهوم الرئيسي؟",
          "quiz_answer_a": "الخيار أ",
          "quiz_answer_b": "الخيار ب", 
          "quiz_answer_c": "الخيار ج",
          "quiz_answer_d": "الخيار د",
          "correct_answer": "A"
        }
      ]
    }
  ]
}

تأكد من أن المحتوى مهني وتعليمي ومناسب لبيئات التدريب في الفصول الدراسية. يجب أن تكون كل دورة مميزة وشاملة.` :
    `Create 5 comprehensive educational training course outlines for these topics: ${topics.join(', ')}

For each course, provide:
1. Course title (professional and engaging)
2. Course description (2-3 sentences)
3. Target audience (specific educator or professional group)
4. Duration (realistic timeframe like "3 hours", "2 days", etc.)
5. Exactly 5 modules, each with:
   - Module title
   - Learning objectives (3-4 objectives separated by semicolons)
   - One multiple choice quiz question with 4 options (A, B, C, D) and the correct answer

Format the response as a JSON object with this exact structure:
{
  "courses": [
    {
      "title": "Course Title",
      "description": "Course description",
      "target_audience": "Target audience",
      "duration": "Duration",
      "modules": [
        {
          "title": "Module 1 Title",
          "learning_objectives": "Objective 1; Objective 2; Objective 3",
          "quiz_question": "What is the main concept?",
          "quiz_answer_a": "Option A",
          "quiz_answer_b": "Option B", 
          "quiz_answer_c": "Option C",
          "quiz_answer_d": "Option D",
          "correct_answer": "A"
        }
      ]
    }
  ]
}

Make sure the content is professional, educational, and suitable for classroom training environments. Each course should be distinct and comprehensive.`;

  try {
    const response = await client.chat.completions.create({
      model: "gpt-4o-mini", 
      messages: [
        {
          role: "system",
          content: isArabic ? 
            "أنت مصمم تعليمي خبير ينشئ مخططات دورات تدريبية مهنية للمعلمين والمهنيين. اجب دائماً بـ JSON صحيح فقط. يجب أن يكون كل المحتوى باللغة العربية." :
            "You are an expert instructional designer who creates professional training course outlines for educators and professionals. Always respond with valid JSON only."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" },
      temperature: 0.7,
      max_tokens: 4000
    });

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("No content received from OpenAI");
    }

    const coursesData = JSON.parse(content);
    
    // Validate the structure
    if (!coursesData.courses || !Array.isArray(coursesData.courses) || coursesData.courses.length !== 5) {
      throw new Error("Invalid courses structure received");
    }

    return coursesData.courses;
  } catch (error) {
    console.error("Error generating multiple courses:", error);
    throw new Error("Failed to generate course outlines");
  }
}

import { Hono } from "hono";
import { cors } from "hono/cors";
import { generateCourse } from "./generate-course";
import { generateMultipleCourses } from "./batch-generate";

const app = new Hono<{ Bindings: Env }>();

app.use("/*", cors());

// Get all courses with their modules
app.get("/api/courses", async (c) => {
  try {
    const coursesResult = await c.env.DB.prepare(`
      SELECT * FROM courses ORDER BY id
    `).all();

    const courses = [];
    for (const course of coursesResult.results) {
      const modulesResult = await c.env.DB.prepare(`
        SELECT * FROM modules 
        WHERE course_id = ? 
        ORDER BY module_order
      `).bind(course.id).all();

      courses.push({
        ...course,
        modules: modulesResult.results
      });
    }

    return c.json({ courses });
  } catch (error) {
    return c.json({ error: "Failed to fetch courses" }, 500);
  }
});

// Generate multiple courses at once
app.post("/api/courses/batch-generate", async (c) => {
  try {
    const body = await c.req.json();
    const { topics, language = 'en' } = body;
    
    if (!topics || !Array.isArray(topics) || topics.length === 0) {
      return c.json({ error: "Topics array is required" }, 400);
    }

    if (!c.env.OPENAI_API_KEY) {
      return c.json({ error: "OpenAI API key not configured" }, 500);
    }

    // Generate multiple courses using OpenAI
    const coursesData = await generateMultipleCourses(topics, c.env.OPENAI_API_KEY, language);
    
    const createdCourses = [];

    // Insert each course into database
    for (const courseData of coursesData) {
      const courseResult = await c.env.DB.prepare(`
        INSERT INTO courses (title, description, target_audience, duration)
        VALUES (?, ?, ?, ?)
      `).bind(
        courseData.title,
        courseData.description,
        courseData.target_audience,
        courseData.duration
      ).run();

      const courseId = courseResult.meta.last_row_id;

      // Insert modules for this course
      for (let i = 0; i < courseData.modules.length; i++) {
        const module = courseData.modules[i];
        await c.env.DB.prepare(`
          INSERT INTO modules (
            course_id, title, learning_objectives, quiz_question,
            quiz_answer_a, quiz_answer_b, quiz_answer_c, quiz_answer_d,
            correct_answer, module_order
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).bind(
          courseId,
          module.title,
          module.learning_objectives,
          module.quiz_question,
          module.quiz_answer_a,
          module.quiz_answer_b,
          module.quiz_answer_c,
          module.quiz_answer_d,
          module.correct_answer,
          i + 1
        ).run();
      }

      // Fetch the complete course with modules
      const modulesResult = await c.env.DB.prepare(`
        SELECT * FROM modules 
        WHERE course_id = ? 
        ORDER BY module_order
      `).bind(courseId).all();

      createdCourses.push({
        id: courseId,
        ...courseData,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
        modules: modulesResult.results
      });
    }

    return c.json({ courses: createdCourses });
  } catch (error) {
    console.error("Error generating multiple courses:", error);
    return c.json({ error: "Failed to generate courses" }, 500);
  }
});

// Generate a new course from a topic
app.post("/api/courses/generate", async (c) => {
  try {
    const body = await c.req.json();
    const { topic, language = 'en' } = body;
    
    if (!topic || typeof topic !== 'string' || topic.trim().length === 0) {
      return c.json({ error: "Topic is required" }, 400);
    }

    if (!c.env.OPENAI_API_KEY) {
      return c.json({ error: "OpenAI API key not configured" }, 500);
    }

    // Generate course using OpenAI
    const courseData = await generateCourse(topic.trim(), c.env.OPENAI_API_KEY, language);
    
    // Insert course into database
    const courseResult = await c.env.DB.prepare(`
      INSERT INTO courses (title, description, target_audience, duration)
      VALUES (?, ?, ?, ?)
    `).bind(
      courseData.title,
      courseData.description,
      courseData.target_audience,
      courseData.duration
    ).run();

    const courseId = courseResult.meta.last_row_id;

    // Insert modules
    for (let i = 0; i < courseData.modules.length; i++) {
      const module = courseData.modules[i];
      await c.env.DB.prepare(`
        INSERT INTO modules (
          course_id, title, learning_objectives, quiz_question,
          quiz_answer_a, quiz_answer_b, quiz_answer_c, quiz_answer_d,
          correct_answer, module_order
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).bind(
        courseId,
        module.title,
        module.learning_objectives,
        module.quiz_question,
        module.quiz_answer_a,
        module.quiz_answer_b,
        module.quiz_answer_c,
        module.quiz_answer_d,
        module.correct_answer,
        i + 1
      ).run();
    }

    // Fetch the complete course with modules
    const modulesResult = await c.env.DB.prepare(`
      SELECT * FROM modules 
      WHERE course_id = ? 
      ORDER BY module_order
    `).bind(courseId).all();

    const newCourse = {
      id: courseId,
      ...courseData,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      modules: modulesResult.results
    };

    return c.json({ course: newCourse });
  } catch (error) {
    console.error("Error generating course:", error);
    return c.json({ error: "Failed to generate course" }, 500);
  }
});

export default app;

import { useState, useEffect } from 'react';
import { CourseWithModules } from '@/shared/types';
import CourseOutline from '@/react-app/components/CourseOutline';
import CreateCourseModal from '@/react-app/components/CreateCourseModal';
import ThemeToggle from '@/react-app/components/ThemeToggle';
import LanguageToggle from '@/react-app/components/LanguageToggle';
import { useLanguage } from '@/react-app/hooks/useLanguage';
import { GraduationCap, Printer, Plus } from 'lucide-react';

export default function Home() {
  const [courses, setCourses] = useState<CourseWithModules[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    // Load Google Fonts
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);

    fetchCourses();
  }, []);

  const fetchCourses = async () => {
    try {
      const response = await fetch('/api/courses');
      if (!response.ok) {
        throw new Error('Failed to fetch courses');
      }
      const data = await response.json();
      setCourses(data.courses);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCourseCreated = () => {
    fetchCourses();
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-beige-50 dark:from-gray-900 dark:to-gray-800">
        <div className="animate-spin mb-4">
          <GraduationCap className="w-12 h-12 text-blue-600 dark:text-blue-400" />
        </div>
        <p className="text-gray-600 dark:text-gray-400">{t('loadingCourses')}</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-beige-50 dark:from-gray-900 dark:to-gray-800">
        <div className="text-red-600 dark:text-red-400 mb-4">
          <GraduationCap className="w-12 h-12" />
        </div>
        <p className="text-gray-600 dark:text-gray-400">Error: {error}</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-beige-50 dark:from-gray-900 dark:to-gray-800 print:bg-white transition-colors duration-200">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-blue-100 dark:border-gray-700 print:border-none print:mb-8 transition-colors duration-200">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-600 dark:bg-blue-700 rounded-xl">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-4xl font-bold text-gray-800 dark:text-gray-200">{t('appTitle')}</h1>
                <p className="text-lg text-gray-600 dark:text-gray-400">{t('appDescription')}</p>
              </div>
            </div>
            
            <div className="flex gap-3 print:hidden">
              <LanguageToggle />
              <ThemeToggle />
              <button 
                onClick={() => setIsCreateModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 bg-green-600 dark:bg-green-700 text-white rounded-lg hover:bg-green-700 dark:hover:bg-green-600 transition-colors font-medium"
              >
                <Plus className="w-4 h-4" />
                {t('createCourse')}
              </button>
              <button 
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 dark:bg-blue-700 text-white rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors"
              >
                <Printer className="w-4 h-4" />
                {t('printAll')}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8 print:hidden">
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 mb-4">{t('availableCourses')}</h2>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            {courses.length === 0 ? t('welcomeMessage') : t('coursesDescription')}
          </p>
        </div>

        {/* Course Outlines */}
        <div className="space-y-12 print:space-y-8">
          {courses.map((course, index) => (
            <div key={course.id} className="print:break-before-page">
              {index > 0 && <div className="print:hidden h-8" />}
              <CourseOutline course={course} />
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-16 pt-8 border-t border-blue-100 dark:border-gray-700 print:hidden">
          <div className="text-center text-gray-500 dark:text-gray-400">
            <p className="mb-2">{t('footerTitle')}</p>
            <p className="text-sm">{t('footerSubtitle')}</p>
          </div>
        </div>
      </div>

      <CreateCourseModal 
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onCourseCreated={handleCourseCreated}
      />
    </div>
  );
}

import { useState, useRef } from 'react';
import { Play, Pause, Volume2, Loader } from 'lucide-react';
import { useLanguage } from '@/react-app/hooks/useLanguage';

interface VoiceExplanationProps {
  text: string;
  title: string;
}

export default function VoiceExplanation({ text, title }: VoiceExplanationProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const { language, t } = useLanguage();

  const handlePlay = async () => {
    if (isPlaying) {
      // Pause current audio
      if (audioRef.current) {
        audioRef.current.pause();
        setIsPlaying(false);
      }
      return;
    }

    setIsLoading(true);
    
    try {
      // Use browser's built-in speech synthesis
      if ('speechSynthesis' in window) {
        // Stop any current speech
        speechSynthesis.cancel();
        
        const utterance = new SpeechSynthesisUtterance();
        utterance.text = `${title}. ${text}`;
        utterance.rate = 0.9;
        utterance.pitch = 1.0;
        utterance.volume = 1.0;
        
        // Try to find a clear, professional voice based on language
        const voices = speechSynthesis.getVoices();
        let preferredVoice;
        
        if (language === 'ar') {
          // Look for Arabic voices
          preferredVoice = voices.find(voice => 
            voice.lang.startsWith('ar') && 
            (voice.name.includes('Google') || voice.name.includes('Microsoft') || voice.name.includes('Nora') || voice.name.includes('Hoda'))
          ) || voices.find(voice => voice.lang.startsWith('ar')) || voices.find(voice => 
            voice.lang === 'ar-SA' || voice.lang === 'ar-EG' || voice.lang === 'ar-JO'
          );
        } else {
          // Look for English voices
          preferredVoice = voices.find(voice => 
            voice.lang.startsWith('en') && 
            (voice.name.includes('Google') || voice.name.includes('Microsoft') || voice.name.includes('Alex'))
          ) || voices.find(voice => voice.lang.startsWith('en'));
        }
        
        // Fallback to any available voice
        if (!preferredVoice) {
          preferredVoice = voices[0];
        }
        
        if (preferredVoice) {
          utterance.voice = preferredVoice;
        }

        utterance.onstart = () => {
          setIsPlaying(true);
          setIsLoading(false);
        };

        utterance.onend = () => {
          setIsPlaying(false);
        };

        utterance.onerror = () => {
          setIsPlaying(false);
          setIsLoading(false);
        };

        speechSynthesis.speak(utterance);
      } else {
        console.error('Speech synthesis not supported');
        setIsLoading(false);
      }
    } catch (error) {
      console.error('Voice synthesis error:', error);
      setIsLoading(false);
    }
  };

  return (
    <button
      onClick={handlePlay}
      disabled={isLoading}
      className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed dark:bg-green-700 dark:hover:bg-green-600"
    >
      {isLoading ? (
        <Loader className="w-4 h-4 animate-spin" />
      ) : isPlaying ? (
        <Pause className="w-4 h-4" />
      ) : (
        <Play className="w-4 h-4" />
      )}
      <Volume2 className="w-4 h-4" />
      {isLoading ? t('loading') : isPlaying ? t('pauseExplanation') : t('playExplanation')}
    </button>
  );
}

import { useState } from "react";
import { CourseWithModules } from "@/shared/types";
import { BookOpen, Clock, Users, Target, Brain } from "lucide-react";
import InteractiveQuiz from "./InteractiveQuiz";
import VoiceExplanation from "./VoiceExplanation";
import VideoLesson from "./VideoLesson";
import { useLanguage } from "@/react-app/hooks/useLanguage";

interface CourseOutlineProps {
  course: CourseWithModules;
}

type ViewMode = 'outline' | 'quiz';

export default function CourseOutline({ course }: CourseOutlineProps) {
  const [viewMode, setViewMode] = useState<ViewMode>('outline');
  const { t } = useLanguage();

  return (
    <div className="bg-white dark:bg-gray-800 border-2 border-blue-100 dark:border-blue-800 rounded-lg p-8 mb-8 shadow-sm print:shadow-none print:border-gray-300 dark:print:border-gray-600">
      {/* Course Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-50 dark:bg-blue-900 rounded-lg">
            <BookOpen className="w-6 h-6 text-blue-600 dark:text-blue-400" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-200">{course.title}</h1>
        </div>
        
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
          {course.description}
        </p>
        
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap gap-6 text-sm">
            <div className="flex items-center gap-2 bg-beige-50 dark:bg-gray-700 px-3 py-2 rounded-md">
              <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="font-medium text-gray-700 dark:text-gray-300">{t('targetAudience')}:</span>
              <span className="text-gray-600 dark:text-gray-400">{course.target_audience}</span>
            </div>
            <div className="flex items-center gap-2 bg-beige-50 dark:bg-gray-700 px-3 py-2 rounded-md">
              <Clock className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span className="font-medium text-gray-700 dark:text-gray-300">{t('duration')}:</span>
              <span className="text-gray-600 dark:text-gray-400">{course.duration}</span>
            </div>
          </div>
          
          <div className="flex gap-2 print:hidden">
            <button
              onClick={() => setViewMode('outline')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                viewMode === 'outline'
                  ? 'bg-blue-600 text-white dark:bg-blue-700'
                  : 'bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-800'
              }`}
            >
              {t('courseOutline')}
            </button>
            <button
              onClick={() => setViewMode('quiz')}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2 ${
                viewMode === 'quiz'
                  ? 'bg-blue-600 text-white dark:bg-blue-700'
                  : 'bg-blue-50 dark:bg-blue-900 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-800'
              }`}
            >
              <Brain className="w-4 h-4" />
              {t('takeQuiz')}
            </button>
          </div>
        </div>
      </div>

      {/* Course Content */}
      {viewMode === 'outline' ? (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 border-b-2 border-blue-100 dark:border-blue-800 pb-2">
            {t('courseModules')}
          </h2>
          
          {course.modules.map((module, index) => (
            <div key={module.id} className="bg-blue-25 dark:bg-gray-700 border border-blue-100 dark:border-blue-800 rounded-lg p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-8 bg-blue-600 dark:bg-blue-700 text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </div>
                <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200">{module.title}</h3>
              </div>
              
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span className="font-medium text-gray-700 dark:text-gray-300">{t('learningObjectives')}:</span>
                </div>
                <div className="pl-6">
                  {module.learning_objectives.split(';').map((objective, objIndex) => (
                    <div key={objIndex} className="flex items-start gap-2 mb-1">
                      <span className="text-blue-600 dark:text-blue-400 mt-1">•</span>
                      <span className="text-gray-600 dark:text-gray-400">{objective.trim()}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Interactive Features */}
              <div className="space-y-4 print:hidden">
                <VoiceExplanation 
                  title={module.title}
                  text={module.learning_objectives.replace(/;/g, '. ')}
                />
                <VideoLesson 
                  title={module.title}
                  content={module.learning_objectives}
                  moduleNumber={index + 1}
                />
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-6">
          <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200 border-b-2 border-blue-100 dark:border-blue-800 pb-2">
            {t('interactiveQuiz')}
          </h2>
          <InteractiveQuiz modules={course.modules} />
        </div>
      )}
    </div>
  );
}

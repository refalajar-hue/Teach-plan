import { useState } from 'react';
import { Module } from '@/shared/types';
import { CheckCircle, XCircle, Award } from 'lucide-react';
import { useLanguage } from '@/react-app/hooks/useLanguage';

interface InteractiveQuizProps {
  modules: Module[];
}

interface QuizState {
  currentModuleIndex: number;
  selectedAnswers: { [moduleId: number]: string };
  showResults: boolean;
  isComplete: boolean;
}

export default function InteractiveQuiz({ modules }: InteractiveQuizProps) {
  const [quizState, setQuizState] = useState<QuizState>({
    currentModuleIndex: 0,
    selectedAnswers: {},
    showResults: false,
    isComplete: false,
  });
  const { t } = useLanguage();

  const currentModule = modules[quizState.currentModuleIndex];
  const totalQuestions = modules.length;

  const handleAnswerSelect = (answer: string) => {
    const moduleId = currentModule.id;
    
    setQuizState(prev => ({
      ...prev,
      selectedAnswers: {
        ...prev.selectedAnswers,
        [moduleId]: answer
      },
      showResults: true
    }));
  };

  const handleNext = () => {
    if (quizState.currentModuleIndex < modules.length - 1) {
      setQuizState(prev => ({
        ...prev,
        currentModuleIndex: prev.currentModuleIndex + 1,
        showResults: false
      }));
    } else {
      setQuizState(prev => ({
        ...prev,
        isComplete: true
      }));
    }
  };

  const handlePrevious = () => {
    if (quizState.currentModuleIndex > 0) {
      setQuizState(prev => ({
        ...prev,
        currentModuleIndex: prev.currentModuleIndex - 1,
        showResults: !!prev.selectedAnswers[modules[prev.currentModuleIndex - 1].id]
      }));
    }
  };

  const calculateScore = () => {
    let correct = 0;
    modules.forEach(module => {
      if (quizState.selectedAnswers[module.id] === module.correct_answer) {
        correct++;
      }
    });
    return correct;
  };

  const resetQuiz = () => {
    setQuizState({
      currentModuleIndex: 0,
      selectedAnswers: {},
      showResults: false,
      isComplete: false,
    });
  };

  if (quizState.isComplete) {
    const score = calculateScore();
    const percentage = Math.round((score / totalQuestions) * 100);
    
    return (
      <div className="bg-white dark:bg-gray-800 border-2 border-blue-100 dark:border-blue-800 rounded-lg p-8 text-center">
        <div className="mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full mb-4">
            <Award className="w-8 h-8 text-blue-600 dark:text-blue-400" />
          </div>
          <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">{t('quizComplete')}</h3>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            {t('score')}: <span className="font-bold text-blue-600 dark:text-blue-400">{score} {t('outOf')} {totalQuestions}</span> {t('correct')}
          </p>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            {t('score')}: <span className="font-bold text-blue-600 dark:text-blue-400">{percentage}%</span>
          </p>
        </div>

        <div className="space-y-3 mb-6">
          {modules.map((module, index) => {
            const userAnswer = quizState.selectedAnswers[module.id];
            const isCorrect = userAnswer === module.correct_answer;
            
            return (
              <div key={module.id} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <span className="text-sm text-gray-700 dark:text-gray-300">Module {index + 1}</span>
                <div className="flex items-center gap-2">
                  {isCorrect ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <XCircle className="w-5 h-5 text-red-500" />
                  )}
                  <span className="text-sm font-medium">
                    {isCorrect ? t('correct') : t('incorrect')}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        <button
          onClick={resetQuiz}
          className="px-6 py-3 bg-blue-600 dark:bg-blue-700 text-white rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors font-medium"
        >
          {t('retakeQuiz')}
        </button>
      </div>
    );
  }

  const selectedAnswer = quizState.selectedAnswers[currentModule.id];
  const isAnswered = !!selectedAnswer;

  return (
    <div className="bg-white dark:bg-gray-800 border-2 border-blue-100 dark:border-blue-800 rounded-lg p-8">
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-semibold text-gray-800 dark:text-gray-200">
            {t('moduleQuiz')} {quizState.currentModuleIndex + 1} {t('quiz')}
          </h3>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            {t('questionOf')} {quizState.currentModuleIndex + 1} {t('of')} {totalQuestions}
          </span>
        </div>
        
        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mb-4">
          <div 
            className="bg-blue-600 dark:bg-blue-500 h-2 rounded-full transition-all duration-300"
            style={{ width: `${((quizState.currentModuleIndex + 1) / totalQuestions) * 100}%` }}
          />
        </div>

        <h4 className="text-lg font-medium text-gray-800 dark:text-gray-200 mb-6">
          {currentModule.quiz_question}
        </h4>

        <div className="space-y-3">
          {[
            { key: 'A', text: currentModule.quiz_answer_a },
            { key: 'B', text: currentModule.quiz_answer_b },
            { key: 'C', text: currentModule.quiz_answer_c },
            { key: 'D', text: currentModule.quiz_answer_d },
          ].map(({ key, text }) => {
            let buttonClass = "w-full p-4 text-left border-2 rounded-lg transition-all duration-200 ";
            
            if (!isAnswered) {
              buttonClass += "border-gray-200 dark:border-gray-600 hover:border-blue-300 dark:hover:border-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/30";
            } else if (key === currentModule.correct_answer) {
              buttonClass += "border-green-300 dark:border-green-600 bg-green-50 dark:bg-green-900/30 text-green-800 dark:text-green-400";
            } else if (key === selectedAnswer) {
              buttonClass += "border-red-300 dark:border-red-600 bg-red-50 dark:bg-red-900/30 text-red-800 dark:text-red-400";
            } else {
              buttonClass += "border-gray-200 dark:border-gray-600 bg-gray-50 dark:bg-gray-700 text-gray-500 dark:text-gray-400";
            }

            return (
              <button
                key={key}
                onClick={() => !isAnswered && handleAnswerSelect(key)}
                disabled={isAnswered}
                className={buttonClass}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="font-bold">{key}.</span>
                    <span>{text}</span>
                  </div>
                  {isAnswered && key === currentModule.correct_answer && (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  )}
                  {isAnswered && key === selectedAnswer && key !== currentModule.correct_answer && (
                    <XCircle className="w-5 h-5 text-red-500" />
                  )}
                </div>
              </button>
            );
          })}
        </div>

        {quizState.showResults && (
          <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-700 rounded-lg">
            <p className="text-sm text-blue-800 dark:text-blue-300">
              {selectedAnswer === currentModule.correct_answer ? (
                <span className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4" />
                  {t('correct')}! {t('greatJob')}.
                </span>
              ) : (
                <span className="flex items-center gap-2">
                  <XCircle className="w-4 h-4" />
                  {t('incorrect')}. {t('correctAnswer')} {currentModule.correct_answer}.
                </span>
              )}
            </p>
          </div>
        )}
      </div>

      <div className="flex justify-between">
        <button
          onClick={handlePrevious}
          disabled={quizState.currentModuleIndex === 0}
          className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {t('previous')}
        </button>
        
        <button
          onClick={handleNext}
          disabled={!isAnswered}
          className="px-6 py-2 bg-blue-600 dark:bg-blue-700 text-white rounded-lg hover:bg-blue-700 dark:hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {quizState.currentModuleIndex === modules.length - 1 ? t('finishQuiz') : t('nextQuestion')}
        </button>
      </div>
    </div>
  );
}

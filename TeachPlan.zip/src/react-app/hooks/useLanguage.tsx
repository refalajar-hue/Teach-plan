import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    appTitle: 'TeachPlan',
    appDescription: 'Professional Classroom Training Course Outlines',
    createCourse: 'Create Course',
    printAll: 'Print All',
    availableCourses: 'Available Course Outlines',
    welcomeMessage: 'Welcome to TeachPlan! Click the "Create Course" button above to generate your first interactive training course. Simply enter any topic and we\'ll create a comprehensive 5-module course outline with learning objectives and interactive quizzes.',
    coursesDescription: 'Below are your training course outlines designed for professional educator development. Each course includes detailed modules with learning objectives and interactive assessment questions. Click "Take Quiz" on any course to test your knowledge with immediate feedback and scoring.',
    createNewCourse: 'Create New Course',
    courseTopic: 'Course Topic',
    topicPlaceholder: 'e.g., Public Speaking, Time Management, Leadership',
    topicHelper: 'Enter a topic and we\'ll generate comprehensive course outlines',
    generateMultiple: 'Generate 5 comprehensive courses',
    multipleHelper: 'Creates a complete curriculum with fundamentals, advanced strategies, applications, leadership, and assessment',
    cancel: 'Cancel',
    generateCourse: 'Generate Course',
    generate5Courses: 'Generate 5 Courses',
    generating: 'Generating...',
    loading: 'Loading...',
    loadingCourses: 'Loading course outlines...',
    playExplanation: 'Play Explanation',
    pauseExplanation: 'Pause Explanation',
    generateSlides: 'Generate Slides',
    takeQuiz: 'Take Quiz',
    nextQuestion: 'Next Question',
    showResults: 'Show Results',
    quizComplete: 'Quiz Complete!',
    retakeQuiz: 'Retake Quiz',
    previous: 'Previous',
    finishQuiz: 'Finish Quiz',
    courseOutline: 'Course Outline',
    courseModules: 'Course Modules',
    learningObjectives: 'Learning Objectives',
    targetAudience: 'Target Audience',
    duration: 'Duration',
    interactiveQuiz: 'Interactive Quiz',
    incorrect: 'Incorrect',
    correctAnswer: 'The correct answer is',
    greatJob: 'Great job',
    moduleQuiz: 'Module',
    quiz: 'Quiz',
    questionOf: 'Question',
    of: 'of',
    score: 'Score',
    outOf: 'out of',
    correct: 'correct',
    tryAgain: 'Try Again',
    footerTitle: 'TeachPlan - Professional Course Development Tools',
    footerSubtitle: 'Generated for educational and training purposes'
  },
  ar: {
    appTitle: 'تيتش بلان',
    appDescription: 'خطط دورات تدريبية مهنية للفصول الدراسية',
    createCourse: 'إنشاء دورة',
    printAll: 'طباعة الكل',
    availableCourses: 'خطط الدورات المتاحة',
    welcomeMessage: 'مرحباً بك في تيتش بلان! اضغط على زر "إنشاء دورة" أعلاه لإنشاء أول دورة تدريبية تفاعلية. ما عليك سوى إدخال أي موضوع وسننشئ خطة دورة شاملة من 5 وحدات مع أهداف التعلم والاختبارات التفاعلية.',
    coursesDescription: 'أدناه خطط الدورات التدريبية المصممة لتطوير المعلمين المهنيين. تتضمن كل دورة وحدات مفصلة مع أهداف التعلم وأسئلة التقييم التفاعلية. اضغط على "إجراء اختبار" في أي دورة لاختبار معرفتك مع التقييم الفوري والنتائج.',
    createNewCourse: 'إنشاء دورة جديدة',
    courseTopic: 'موضوع الدورة',
    topicPlaceholder: 'مثال: الخطابة العامة، إدارة الوقت، القيادة',
    topicHelper: 'أدخل موضوعاً وسننشئ خطط دورات شاملة',
    generateMultiple: 'إنشاء 5 دورات شاملة',
    multipleHelper: 'ينشئ منهجاً كاملاً مع الأساسيات والاستراتيجيات المتقدمة والتطبيقات والقيادة والتقييم',
    cancel: 'إلغاء',
    generateCourse: 'إنشاء دورة',
    generate5Courses: 'إنشاء 5 دورات',
    generating: 'جاري الإنشاء...',
    loading: 'جاري التحميل...',
    loadingCourses: 'جاري تحميل خطط الدورات...',
    playExplanation: 'تشغيل الشرح',
    pauseExplanation: 'إيقاف الشرح',
    generateSlides: 'إنشاء الشرائح',
    takeQuiz: 'إجراء اختبار',
    nextQuestion: 'السؤال التالي',
    showResults: 'عرض النتائج',
    quizComplete: 'اكتمل الاختبار!',
    retakeQuiz: 'إعادة الاختبار',
    previous: 'السابق',
    finishQuiz: 'إنهاء الاختبار',
    courseOutline: 'مخطط الدورة',
    courseModules: 'وحدات الدورة',
    learningObjectives: 'أهداف التعلم',
    targetAudience: 'الجمهور المستهدف',
    duration: 'المدة',
    interactiveQuiz: 'اختبار تفاعلي',
    incorrect: 'غير صحيح',
    correctAnswer: 'الإجابة الصحيحة هي',
    greatJob: 'عمل رائع',
    moduleQuiz: 'وحدة',
    quiz: 'اختبار',
    questionOf: 'سؤال',
    of: 'من',
    score: 'النتيجة',
    outOf: 'من',
    correct: 'صحيح',
    tryAgain: 'المحاولة مرة أخرى',
    footerTitle: 'تيتش بلان - أدوات تطوير الدورات المهنية',
    footerSubtitle: 'تم إنشاؤه لأغراض تعليمية وتدريبية'
  }
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('teachplan-language');
    return (saved as Language) || 'en';
  });

  useEffect(() => {
    localStorage.setItem('teachplan-language', language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
